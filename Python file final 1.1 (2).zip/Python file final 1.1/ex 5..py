import numpy as np


def get_grade(final_grade, exam_grade, coursework_grade):
    """
    Gets the grade based on the final grade, exam grade, and coursework grade.

    Parameters:
    final_grade (float): The final grade calculated from exam and coursework.
    exam_grade (float): The exam grade.
    coursework_grade (float): The coursework grade.

    Returns:
    str: The grade ('Distinction', 'Merit', 'Pass', or 'Fail').
    """
    if final_grade >= 70 and exam_grade >= 65 and coursework_grade >= 65:
        return 'Distinction'
    elif final_grade >= 60:
        return 'Merit'
    elif final_grade >= 45:
        return 'Pass'
    else:
        return 'Fail'


def main():
    # Get the file name from the user
    filename = input("Enter the filename: ")

    try:
        # Open the file for reading
        with open(filename, 'r') as file:
            # Read the first line: number of students and coursework weighting
            first_line = file.readline().strip().split()
            num_students = int(first_line[0])  # The number of students
            coursework_weighting = float(first_line[1]) / 100.0  # Convert to percentage

            # Initialize a 2D NumPy array with zeros
            student_data = np.zeros(
                (num_students, 4))  # 4 columns: reg number, exam grade, coursework grade, final grade

            # Read the student data from the file
            for i in range(num_students):
                line = file.readline().strip().split()
                reg_num = int(line[0])  # Registration number of the student
                exam_grade = float(line[1])  # Exam grade of the student
                coursework_grade = float(line[2])  # Coursework grade of the student

                # Calculate the final grade
                final_grade = exam_grade * (1 - coursework_weighting) + coursework_grade * coursework_weighting

                # Store the data in the array
                student_data[i] = [reg_num, exam_grade, coursework_grade, final_grade]

            # Define the custom dtype for output
            student_dtype = np.dtype([('RegNum', 'i4'), ('ExamGrade', 'f4'), ('CourseworkGrade', 'f4'),
                                      ('FinalGrade', 'f4'), ('Grade', 'U12')])  # U12 for grade string

            # Create a new array using the custom dtype
            output_data = np.zeros(num_students, dtype=student_dtype)

            # Populate the output array with the calculated grades
            for i in range(num_students):
                reg_num = int(student_data[i][0])  # Registration number
                exam_grade = int(student_data[i][1])  # Exam grade
                coursework_grade = int(student_data[i][2])  # Coursework grade
                final_grade = int(student_data[i][3])  # Final grade
                grade = get_grade(final_grade, exam_grade, coursework_grade)  # Get the grade based on final marks

                # Store the data in the output array
                output_data[i] = (reg_num, exam_grade, coursework_grade, final_grade, grade)

            # Sort the output array by final grade
            sorted_output = np.sort(output_data, order='FinalGrade')[::-1]  # Sort in descending order

            # Output the sorted data to a file
            with open("sorted_student_data.txt", 'w') as f:
                print(sorted_output, file=f)

            # Count the grades
            distinctions = np.sum(sorted_output['Grade'] == 'Distinction')  # Count the number of Distinctions
            merits = np.sum(sorted_output['Grade'] == 'Merit')  # Count the number of Merits
            passes = np.sum(sorted_output['Grade'] == 'Pass')  # Count the number of Passes
            fails = np.sum(sorted_output['Grade'] == 'Fail')  # Count the number of Fails

            # Output the grade statistics
            print(f"Distinctions: {distinctions}")
            print(f"Merits: {merits}")
            print(f"Passes: {passes}")
            print(f"Fails: {fails}")

            # Output the registration numbers of students who failed
            failed_students = sorted_output[sorted_output['Grade'] == 'Fail']  # Filter failed students
            print("Failed Students' Registration Numbers: ")
            for student in failed_students:
                print(student['RegNum'])

    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")  # File not found error message
    except Exception as e:
        print(f"Error: {str(e)}")  # Catch all unexpected errors


main()