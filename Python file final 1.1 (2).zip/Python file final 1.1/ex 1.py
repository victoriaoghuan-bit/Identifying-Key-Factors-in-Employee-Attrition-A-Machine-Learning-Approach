from datetime import date
import datetime

def get_age(birth_date):
    """
       Calculates the person's age based on their birth date.

       Args:
       birth_date (datetime.date): The person's birthdate.

       Returns:
       int: The calculated age in years.
       """

    today = date.today()
    age = today.year - birth_date.year # Calculate age by the difference in today's year and birth year

    # Checks if birthday has already occurred this year
    if today.month < birth_date.month or (today.month == birth_date.month and today.day < birth_date.day):
        age -= 1

    return age

# Input with exact format instructions
birth_date_str = input("Enter your date of birth in DD/MM/YYYY format: ")

try:
    # Convert the input (birth date) string to a date object
    birth_date = datetime.datetime.strptime(birth_date_str, "%d/%m/%Y").date()

    # Check if the birthdate is in the future
    if birth_date > date.today():
        raise ValueError("Invalid birth date: Can't be a future date.")

    # Calculate the age
    age = get_age(birth_date)
    print(f"You are {age} years old.")

    #If the user is younger than 5 years old print a message
    if age < 5:
        print("You are too young to use a computer!")

except ValueError:
    # Handle incorrect date format or invalidate date
    print("Error: Incorrect date format or invalid date.") #
