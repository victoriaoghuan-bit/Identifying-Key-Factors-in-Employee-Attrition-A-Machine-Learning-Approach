def is_prime(num):
    """Checks if the number is prime.

    Arguments:
    num: The number that's checked.

    Returns:
    bool:True if the number is prime and false if not.
    """
    if num <= 1:  # Prime numbers must be bigger than 1
        return False
    # check factors up to the square root of the number.
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:  # If divisible by any number, it's not prime.
            return False
    return True  # If no divisors were found, it is prime.


def get_non_primes(start, end):
    """
    # This function generates numbers in the range from start to end (inclusive) and checks if each number is not prime, and returns a list of the non-prime numbers within the range.

    Arguments:
    start:The start of the range (integer).
    end:The end of the range (integer).

    Returns:
    list:A list of non prime numbers in the range.
    """
    # List comprehension to filter out prime numbers
    return [num for num in range(start, end + 1) if not is_prime(num)]  # Use the prime check function


def main():
    """Main function that interacts with the user, handles input, and returns non prime numbers
    This function repeatedly prompts the user for two positive integers and returns a list of
    no prime numbers  in therange. The output is printed in rows of 8 numbers.
    If the input is invalid the function will request another input
    """

    while True:  # loop to allow for re-tries in case of invalid input
        try:
            # Take user input for the range
            start = int(input("Enter the first positive integer: "))  # First number (inclusive)
            end = int(input("Enter the second positive integer: "))  # Second number (inclusive)

            # Check that integers are positive
            if start <= 0 or end <= 0:
                raise ValueError("Both numbers should be positive integers.")  # Raise error if not positive integer

            # Sort the range in case the user enters the numbers unordered or reverse ordered
            lower, upper = sorted([start, end])

            # Get the list of non prime numbers
            non_primes = get_non_primes(lower, upper)

            # If non primes there print them in lines of 8 else print a message
            if non_primes:
                print("Non primes numbers in the range:")
                for i in range(0, len(non_primes), 8):  # Print in groups od 8 numbers per line
                    print(*non_primes[i:i + 8])#The `*` operator spreads the list items as separate arguments for the  print  function.
            else:
                print("No non primes numbers in the range.")  # No non primes found in the range

            break

        except ValueError:  # If input is invalid (non integer or other invalid input)
            print("Invalid input. Enter positive integers .")


#Call the main function to begin
main()

