def fun1(s):
    s = s.lower()
    """
    Checks if string is a palindrome and is not case sensitive.

    Args: s (str): The string to check.

    Returns: bool: True if the string is a palindrome, otherwise False.
    """
    s = s.lower()  # Convert string to lowercase characters
    return s == s[::-1]  # Check if the string is equal to its reverse

def fun2(string):
    """Finds the most frequent character/digit in a string.

        Args: string (str): The input string.

        Returns: str: The most frequent letter/digit, returns None if there are no letter/digit characters
    """
    freq = {}  # Dictionary to store the frequency of each letter/digit

    for char in string.lower():  # Loop through characters in string converting them to lowercase
        if char.isalnum():  # If letters or digit characters
            freq[char] = freq.get(char, 0) + 1  # Increment the frequency

    if not freq:  # If no letter/digit character is there, then return None
        return None

    return max(freq, key=freq.get)  # Return character that is most frequent

def fun3(string):
    """Counts the number of uppercase, lowercase, and space characters in a string.

        Args: string (str): The input string.

        Returns: tuple: A tuple with three integers: the number of uppercase and lowercase letters, and the number of spaces.
    """
    upper_count = sum(1 for char in string if char.isupper())

    lower_count = sum(1 for char in string if char.islower())

    space_count = string.count(' ')

    return upper_count, lower_count, space_count
print(fun1("Hello World!"))
print(fun2("Hello World!"))
print(fun3("Hello World!"))




