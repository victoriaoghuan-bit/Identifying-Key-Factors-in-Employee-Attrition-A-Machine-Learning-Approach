def show_employees(employee_list, min_salary):
    """
    The function filters and shows employees whose salary is equal to or bigger than the specific minimum salary.

    Args:
    employee_list (list): A list of tuples, each with an employee's name, job title, and salary.
    min_salary (int): The minimum salary used to select the employees.

    Returns:
    None
    """

    selected_employees = [emp for emp in employee_list if emp[2] >= min_salary]  # Selects employees whose salary is equal to or greater than the minimum salary
    selected_employees.sort(key=lambda x: x[2], reverse=True)  # Sort the selected employees by their salary in descending order

    if not selected_employees:  # If no employees meet the standard print appropriate message to the user
        print("No employees have salary greater than or equal to", min_salary)
    else:
        #Format the header and employee job title and salary
        print(f"\n{'Name':<20}{'Job Title':<20}{'Salary':<10}")
        print("-" * 50)
        for name, job, salary in selected_employees:
            print(f"{name:<20}{job:<20}{salary:<10}")


def main(): #Call main function
    filename = input("Enter the file name: ")       # Ask the user to enter the appropriate file
    try:
        with open(filename, "r") as file:   # Open and read the file
            employee_list = []

               # Read the lines of the file, split by the commas, and convert salary to integer
            for line in file:
                name, job, salary = line.strip().split(",")       # Splits the line
                employee_list.append((name, job, int(salary)))        # Adds tuple to list of employee

        print("\nEmployee List (Unformatted):")      # Prints unformatted data for reference
        print(employee_list)

        # Allows for conditional loops to be applied to the salaries
        while True:
            try:
                min_salary = int(input("\nEnter a salary to select employees: "))        # Asks user to enter salary cutoff
                show_employees(employee_list, min_salary)          # Shows the employees based on their salary
            except ValueError:                                     # Handles invalid salary input by printing error message
                print("Please enter a valid integer salary.")

            choice = input("Do you want to enter another salary? (yes/no): ").strip().lower()    #Ask the user if they want to continue entering more salieries
            if choice != 'yes':
                print("bye!")      # Leaves the loop f the user enters no
                break

    except FileNotFoundError:     # Handles if the file can not open
        print("Error: File can not open.")


# Call the main function to start the program
main()
